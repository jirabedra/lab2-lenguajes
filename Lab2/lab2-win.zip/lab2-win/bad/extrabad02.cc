int main() {
  int i = "str";
}
