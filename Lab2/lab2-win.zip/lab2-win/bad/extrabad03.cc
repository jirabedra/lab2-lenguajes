int main() {
  double a = 2.5;
  int b = (a = "str");
}
