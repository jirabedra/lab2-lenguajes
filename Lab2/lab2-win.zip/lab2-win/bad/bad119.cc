int main () {
	return true - 0;
}
