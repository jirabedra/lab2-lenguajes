int foo() {
  return 1 + "some exp";
}
