int main () {
  if (false - true)
	int x = 45;
  else { }
  return 0;
}
