int main() {
  string str = "string exp";
  double dbl = 2.3;
  int i = 1;
  bool b = true;

  bool res1 = b && i < dbl;
  double res2 = dbl * i;
  double res3 = i / dbl;
  string res4 = str + dbl;
  string res5 = i + str;
}
