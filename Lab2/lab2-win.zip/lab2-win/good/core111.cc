int main () {
  printInt(readInt()-1);
  return 0;
}

void printInt(int x) { }
int readInt() { return 4; }
