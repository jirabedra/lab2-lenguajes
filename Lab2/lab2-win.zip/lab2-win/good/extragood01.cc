string foo() {
  return "1";
}
