int main() {
  double a = 2.5;
  string b = a + "hola";
}
