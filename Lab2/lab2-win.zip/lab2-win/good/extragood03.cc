int main() {
  string str = "1";
  double dbl = 1.0;
  int i = 1;
}
