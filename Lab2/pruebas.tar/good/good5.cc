double f(int a, double b, bool c){
      int i = 2 ;
      b = 2.0; // using function parameters
}


