int f(int a, int b,int c){
  bool d = a <= a && a >= a || b < b || b > b || c != a; // check  boolean expresions 
  int i = 2 ;
  b = a; // secure implicit casting
}
