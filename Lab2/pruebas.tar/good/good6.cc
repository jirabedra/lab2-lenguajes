double f(int a, double b, bool c){
  int i = 2 ;
}

double g(int a, double b, bool c){
  double i = f(a,b,c) ; // functions applications
}
