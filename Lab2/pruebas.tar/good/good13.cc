int f(int a, double b,int c){
  int i;
  {
    double i; // could redefine a variable in an inner block
  }
}
