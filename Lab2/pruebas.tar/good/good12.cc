int f(int a, double b,int c){
  int i,j;
  int k;
  k = i + j;
}
