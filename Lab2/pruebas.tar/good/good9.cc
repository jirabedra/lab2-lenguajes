int f(int a, double b,int c){
  bool d = a <= a && a >= a || b < b || b > b || c != a; // check  boolean expresions 
  int i = 2 ;
}
