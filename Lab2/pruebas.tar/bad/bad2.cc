bool f (int c)  
{
  int n = 1 ;
  while (c + 1) ++n ; // while condition is not boolean
  return c;
}                   

