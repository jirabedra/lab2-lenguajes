double f(int a, double b,int c){
  int i = 2;
  c = b; // not secure implicit casting
}



