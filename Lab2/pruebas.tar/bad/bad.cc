// file bad.cc
  
int f (double c)  
{
  int n = 1 ;
  while (c) ++n ; // while condition is not boolean
}                   

