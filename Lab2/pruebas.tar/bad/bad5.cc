double f(int a, double b, string c){
      int i = 2 ;
      b = c;
}


