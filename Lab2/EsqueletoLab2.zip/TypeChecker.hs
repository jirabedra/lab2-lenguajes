module TypeChecker where

import AbsCPP
import PrintCPP
import ErrM
import Env

import Control.Monad

-- Método principal
typecheck :: Program -> Err ()
typecheck p = fail "No implementado"


-- Métodos secundarios
-- Pueden agregar más método y modificar firmas de los ya declarados

inferExp :: Env -> Exp -> Err Type
inferExp = undefined

checkExp :: Env -> Exp -> Type -> Err ()
checkExp = undefined

checkStms :: Type -> Env -> [Stm] -> Err Env
checkStms = undefined

checkStm :: Type -> Env -> Stm -> Err Env
checkStm = undefined

checkDef :: Env -> Def -> Err ()
checkDef = undefined