module Env where

import AbsCPP
import PrintCPP
import ErrM

import qualified Data.Map.Strict as Map

-- Pueden hacer uso de las funciones de Map

-- Definición de un Environment
type Env = (Sig,[Context])
type Sig = Map.Map Id ([Type],Type)
type Context = Map.Map Id Type


lookupVar :: Env -> Id -> Err Type
lookupVar = undefined

lookupFun :: Env -> Id -> Err ([Type], Type)
lookupFun = undefined

updateVar :: Env -> Id -> Type -> Err Env
updateVar = undefined

updateFun :: Env -> Id -> ([Type],Type) -> Err Env
updateFun = undefined

newBlock :: Env -> Env
newBlock = undefined

emptyEnv :: Env
emptyEnv = undefined
