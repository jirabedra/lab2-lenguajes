// declaration and initialization in same statement

int main() {
 int x = 7;
 printInt(x);
 return 0 ;
}

void printInt(int x) { }
void printDouble(double x) { }
