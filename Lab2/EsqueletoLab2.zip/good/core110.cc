int main() {
  printInt(24);
  return 0;
}

void printInt(int x) { }
