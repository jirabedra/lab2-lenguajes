int main() {
        x;
	return 0 ;
}
