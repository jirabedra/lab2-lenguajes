int main() {
  if (1.0) {

  } else {}
  return 0;
}
