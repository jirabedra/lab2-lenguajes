int main() {
	return x ;
}
